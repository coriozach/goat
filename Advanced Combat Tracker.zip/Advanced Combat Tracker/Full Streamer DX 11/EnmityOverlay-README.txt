# EnmityPlugin

※ 2015.06.23現在、蒼天のイシュガルド(3.0)では動作しません。
[Issue 6](https://github.com/xtuaok/ACT_EnmityPlugin/issues/6) 


現在のターゲットの敵視量、距離、HP等をオーバーレイ表示する、[OverlayPlugin](https://github.com/RainbowMage/OverlayPlugin) のアドオンです。 

![sample](https://raw.githubusercontent.com/xtuaok/ACT_EnmityPlugin/master/sample.png) 

[OverlayPlugin](https://github.com/RainbowMage/OverlayPlugin) (**0.3.1.0以降**)のアドオンとして動作するため、 [OverlayPlugin](https://github.com/RainbowMage/OverlayPlugin) の導入が必要です。

## ダウンロード

[リリースページ](https://github.com/xtuaok/ACT_EnmityPlugin/releases/latest)よりダウンロードできます。

## ドキュメント

インストールや使い方は [Wiki](https://github.com/xtuaok/ACT_EnmityPlugin/wiki) を参照してください。
